<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/css/bundle.css', 'resources/css/font-awesome.min.css']); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/js/bundle.js', 'resources/js/app.js', 'resources/js/font-awesome.min.js']); ?>
    </head>
    

    <body :class="{'dark bg-gray-900': darkMode === true}" x-data="{ page: 'images', 'loaded': true, 'darkMode': false, 'stickyMenu': false, 'sidebarToggle': false, 'scrollTop': false }" x-init="
         darkMode = JSON.parse(localStorage.getItem('darkMode'));
         $watch('darkMode', value => localStorage.setItem('darkMode', JSON.stringify(value)))">

        <!-- ===== Preloader Start ===== -->
        <div class="fixed left-0 top-0 z-999999 flex h-screen w-screen items-center justify-center bg-white dark:bg-black" x-init="window.addEventListener('DOMContentLoaded', () => {setTimeout(() => loaded = false, 500)})" x-show="loaded">
            <div class="h-16 w-16 animate-spin rounded-full border-4 border-solid border-brand-500 border-t-transparent">
            </div>
        </div>
        <!-- ===== Preloader End ===== -->

        <div class="flex h-screen overflow-hidden">
            <?php echo $__env->make('layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <!-- Page Content -->
            <div class="relative flex flex-col flex-1 overflow-x-hidden overflow-y-auto">
                <!-- Header -->
                <?php echo $__env->make('layouts.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                <!-- Main Content -->
                <main class="flex-1 p-8 transition-all duration-300 ease-in-out"
                      :class="{ 'pl-64': isOpen, 'pl-0': !isOpen }"
                      x-data="{ isOpen: true }">
                    
                    <!-- Page Heading -->
                    <?php if(isset($header)): ?>
                        <header class="bg-white shadow">
                            <div class="max-w-7xl mx-auto-- py-6 px-4 sm:px-6 lg:px-8">
                                <?php echo e($header); ?>

                            </div>
                        </header>
                    <?php endif; ?>
                    
                    <?php echo e($slot); ?>

                </main>
            </div>
        </div>



    </body>
</html>
<?php /**PATH D:\xampp\htdocs\erp2\resources\views/layouts/app.blade.php ENDPATH**/ ?>